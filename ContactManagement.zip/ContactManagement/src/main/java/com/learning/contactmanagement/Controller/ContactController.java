package com.learning.contactmanagement.Controller;

import com.learning.contactmanagement.Entity.Contact;
import com.learning.contactmanagement.Entity.GenericModel.GenericResult;
import com.learning.contactmanagement.Service.ConfigureLogService.LoggerConfigure;
import com.learning.contactmanagement.Service.ContactService.ContactService;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/contact")
public class ContactController {

    @Autowired
    private ContactService contactService;
    private LoggerConfigure loggerConfigure;

    @PreAuthorize("hasRole('USER')")
    @PostMapping
    public ResponseEntity<GenericResult<Contact>> createContact(@RequestBody Contact contact) {
        try {
            Contact savedContact = contactService.saveContact(contact);
            return new ResponseEntity<>(new GenericResult<>(true, "Contact created successfully", savedContact), HttpStatus.CREATED);
        } catch (Exception e) {
            logError("Error creating contact", e);
            return new ResponseEntity<>(new GenericResult<>(false, "Error creating contact", null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<GenericResult<Contact>> updateContact(@PathVariable String id, @RequestBody Contact updatedContact) {
        try {
            GenericResult<Contact> result = new GenericResult<>();
            Contact existingContact = contactService.getContactById(id);

            if (existingContact != null) {
                existingContact.setContact_Name(updatedContact.getContact_Name());
                existingContact.setContact_Email(updatedContact.getContact_Email());
                existingContact.setContact_Phone(updatedContact.getContact_Phone());
                Contact savedContact = contactService.saveContact(existingContact);

                result.setSuccess(true);
                result.setMessage("Contact updated successfully");
                result.setData(savedContact);
                return new ResponseEntity<>(result, HttpStatus.OK);
            } else {
                result.setSuccess(false);
                result.setMessage("Error in updating contact with id " + id + ". Contact not found.");
                result.setData(null);
                return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            logError("Error updating contact", e);
            return new ResponseEntity<>(new GenericResult<>(false, "Error updating contact", null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<GenericResult<String>> deleteContactById(@PathVariable String id) {
        try {
            String result = contactService.deleteContactById(id);
            return new ResponseEntity<>(new GenericResult<>(true, "Contact deleted successfully", result), HttpStatus.OK);
        } catch (Exception e) {
            logError("Error deleting contact", e);
            return new ResponseEntity<>(new GenericResult<>(false, "Error deleting contact", null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping
    public ResponseEntity<GenericResult<String>> deleteMultipleContacts(@RequestBody List<String> ids) {
        try {
            String result = contactService.deleteMultipleContacts(ids);
            return new ResponseEntity<>(new GenericResult<>(true, "Contacts deleted successfully", result), HttpStatus.OK);
        } catch (Exception e) {
            logError("Error deleting multiple contacts", e);
            return new ResponseEntity<>(new GenericResult<>(false, "Error deleting multiple contacts", null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    public ResponseEntity<GenericResult<Page<Contact>>> getAllContacts(
            @RequestParam(required = false) Map<String, String> filters,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String order) {
        try {
            GenericResult<Page<Contact>> result = contactService.getAllContacts(filters, page, size, sortBy, order);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            logError("Error getting all contacts", e);
            return new ResponseEntity<>(new GenericResult<>(false, "Error getting all contacts", null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void logError(String message, Exception e) {
        Logger customLog = loggerConfigure.customLog();
        customLog.error(message, e);
    }

}

package com.learning.contactmanagement.Service.ConfigureLogService;

import org.slf4j.Logger;

public interface LoggerConfigure {
    Logger customLog();

}

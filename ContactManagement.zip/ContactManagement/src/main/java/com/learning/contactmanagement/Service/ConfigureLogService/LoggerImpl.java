package com.learning.contactmanagement.Service.ConfigureLogService;

import com.learning.contactmanagement.Entity.Contact;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.logging.Level;

@Component
public class LoggerImpl implements LoggerConfigure {
    private static final Logger logger = LoggerFactory.getLogger(Contact.class);

    @Override
    public Logger customLog() {
        logger.info("Data Saved Successfully..!");
        return null;
    }

    public void doSomething() {
        if (logger == null) {
            logger.info("loggerConfigure is null. Displaying some messages...");
        }
        else {
            logger.info("loggerconfigure is not null");
        }

    }
}
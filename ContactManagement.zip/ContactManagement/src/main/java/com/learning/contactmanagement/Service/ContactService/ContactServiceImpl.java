package com.learning.contactmanagement.Service.ContactService;

import com.learning.contactmanagement.Entity.Contact;
import com.learning.contactmanagement.Entity.GenericModel.GenericRequest;
import com.learning.contactmanagement.Entity.GenericModel.GenericResult;
import com.learning.contactmanagement.Repository.ContactRepository;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;


import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ContactServiceImpl implements ContactService {

    private final ContactRepository contactRepo;

    @Autowired
    public ContactServiceImpl(ContactRepository contactRepo) {
        this.contactRepo = contactRepo;
    }

    @Override
    public Contact saveContact(Contact contact) {
        return contactRepo.save(contact);
    }

    @Override
    public Contact getContactById(String id) {
        Optional<Contact> optionalContact = contactRepo.findById(Integer.valueOf(id));
        return optionalContact.orElse(null);
    }

    @Override
    public Page<Contact> getAllContacts(Map<String, String> filters, Pageable pageable) {
        if (filters == null) {
            throw new IllegalArgumentException("Filters cannot be null");
        }

        Page<Contact> contacts = contactRepo.findAll(pageable);

        return contacts;
    }

    @Override
    public GenericResult<Contact> updateContact(String id, GenericRequest<Contact> contactRequest) {
        Contact existingContact = contactRepo.findById(Integer.valueOf(id)).orElse(null);
        if (existingContact == null) {
            return GenericResult.error("Contact not found");
        }

        Contact updatedContact = contactRequest.getRequestData();
        existingContact.setContact_Name(updatedContact.getContact_Name());
        existingContact.setContact_Email(updatedContact.getContact_Email());
        existingContact.setContact_Phone(updatedContact.getContact_Phone());
        Contact savedContact = contactRepo.save(existingContact);

        return GenericResult.error(savedContact);
    }



    @Override
    public String deleteContactById(String id) {
        contactRepo.deleteById(Integer.valueOf(id));
        return "Contact deleted successfully";
    }

    @Override
    public String deleteMultipleContacts(List<String> ids) {
        // Convert the List<String> to List<Integer>
        List<Integer> integerIds = ids.stream()
                .map(Integer::valueOf)
                .collect(Collectors.toList());

        // Call deleteAllById with the List<Integer>
        contactRepo.deleteAllById(integerIds);

        return "Contacts deleted successfully";
    }


    @Override
    public GenericResult<Page<Contact>> getAllContacts(Map<String, String> filters, int page, int size, String sortBy, String order) {
        GenericResult<Page<Contact>> result = new GenericResult<>();
        Sort.Direction direction = order.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Sort sort = Sort.by(direction, sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<Contact> contactPage;
        if (filters != null && !filters.isEmpty()) {
            Map.Entry<String, String> entry = filters.entrySet().iterator().next();
            contactPage = (!isPageKey(entry.getKey())) ?
                    contactRepo.findByFilter(entry.getKey(), entry.getValue(), pageable) :
                    contactRepo.findAll(pageable);
            result.setSuccess(true);
            result.setMessage("Contacts retrieved successfully");
            result.setData(contactPage);
            // Log additional information if needed
        }
        else {
            contactPage = contactRepo.findAll(pageable);
            result.setSuccess(true);
            result.setMessage("All contacts retrieved successfully");
            result.setData(contactPage);
            // Log additional information if needed
        }
        return result;
    }
    public GenericResult<Contact> updateContact(String id, Contact contact) {

        Contact existingContact = contactRepo.findById(Integer.valueOf(id)).orElse(null);
        if (existingContact == null) {
            return GenericResult.error("Contact not found");
        }


        existingContact.setContact_Name(contact.getContact_Name());
        existingContact.setContact_Email(contact.getContact_Email());
        existingContact.setContact_Phone(contact.getContact_Phone());

        Contact savedContact = contactRepo.save(existingContact);

        return GenericResult.error(savedContact);
    }


    private boolean isPageKey(String key) {
        return key.equals("page") || key.equals("size") || key.equals("sortBy") || key.equals("order");
    }



}
